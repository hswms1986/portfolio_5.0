/*
   CS 5000/01
Fall 2015
Henry Williams  
Dr. Haddad
Assignment 8 TestLocation
 */
package location;
import java.util.Scanner;
/**
 *
 * @author Steven
 */
public class TestLocation {
    public static void main(String[] args) {
        Scanner scan1 = new Scanner(System.in);
        System.out.print("Enter the number of rows and columns:");
        int r = scan1.nextInt();
        int c = scan1.nextInt();
        
        double[][] arr = new double[r][c];
        
        System.out.println("Enter the array");
        
        for(int i=0; i < arr.length; i ++) {
            for(int j = 0; j < arr[0].length; j++) {
                arr[i][j] = scan1.nextDouble();
                
            }
        }
        Location locate = new Location();
        Location var2 = locate.locateLargest(arr);
        System.out.println("The location of the largest element is:" 
        + var2.getMaxValue() + " at (" + var2.getRow() + "," + var2.getColumn() + ")");  
    }
    
}
