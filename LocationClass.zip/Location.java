/*
   CS 5000/01
Fall 2015
Henry Williams  
Dr. Haddad
Assignment 8 Location
 */
package location;

/**
 *
 * @author Steven
 */
public class Location {

   int row;
   int column;
   double [][] a;
   double maxValue;
   
   public Location() {
       row = 0;
       column = 0;
       maxValue = 0.0;
   }
   
   public Location(int r, int c, double mV) {
       row = r;
       column = c;
       maxValue = mV;
   }
   
   public int getRow() {
       return row;
   }
   
   public int getColumn(){
       return column;
   }
   
   public double getMaxValue() {
       return maxValue;
   }
   
   public static Location locateLargest(double[][] a) {
       double max = a[0][0];
       int ro = 0;
       int co = 0;
               
       for(int i = 0; i < a.length; i ++) {
           for(int j = 0; j < a[0].length; j ++) {
               if(max < a[i][j]){
                   max = a[i][j];
                   ro = i;
                   co = j;
               }
           }
           
           
       }
       return new Location(ro, co, max);
   }
    
    
}
