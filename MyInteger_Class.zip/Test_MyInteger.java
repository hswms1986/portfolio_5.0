/*
 CS 5000/01
Fall 2015
Henry Williams  
Dr. Haddad
Assignment 9 Test_MyInteger
 */
package myinteger;

/**
 *
 * @author Steven
 */
public class Test_MyInteger{
    public static void main(String[] args){
    MyInteger num1 = new MyInteger(36457);
    System.out.println("Is num1 even?" + num1.isEven());
    System.out.println("Is num1 odd?" + num1.isOdd());
    System.out.println("36457 is prime? " + MyInteger.isPrime(num1));
    
    MyInteger num2 = new MyInteger(2345);
    System.out.println("Is num1 even?" + num1.isEven());
    System.out.println("Is num1 odd?" + num1.isOdd());
    System.out.println("2345 is prime? " + MyInteger.isPrime(num2));
    }
}
