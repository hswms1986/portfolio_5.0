/*
   CS 5000/01
Fall 2015
Henry Williams  
Dr. Haddad
Assignment 9 MyInteger
 */
package myinteger;

/**
 *
 * @author Steven
 */
public class MyInteger {

    int value;
    
    public MyInteger(int value) {
        this.value = value;
    }
    
    public Integer getValue() {
        return value;
    }
    
    public boolean isEven() {
        if(value % 2 == 0){
            return true;
        } else {
            return false;
        }
    }
    public boolean isOdd() {
        if(value % 2 != 0){
            return true;
        } else {
            return false;
        }
    }
        
    public boolean isPrime() {
        int n = 2;
        while(n<value){
            if(value % n == 0){
                return false;
            } 
            n++;
        }
        return true;
    }
    public boolean isEven(int num){
        if(num % 2 == 0){
            return true;
        } else {
            return false;
        }
    }
    public boolean isOdd(int num) {
        if(num % 2 == 0){
            return false;
        } else {
            return true;
        }
    }
    
    public static boolean isPrime(MyInteger num){
        return num.isPrime();
    }
    public static boolean isEven(MyInteger nombre) {
        return nombre.isEven(nombre.getValue());
    }
    
    }
   
    
    
