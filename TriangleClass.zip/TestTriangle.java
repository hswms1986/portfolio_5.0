/*
  CS 5000/01
Fall 2015
Henry Williams  
Dr. Haddad
Assignment 10 TestTriangle
 */
package triangle;
import java.util.Scanner;

/**
 *
 * @author Steven
 */
public class TestTriangle extends Triangle {
    public static void main(String [ ] args)
{
  Scanner r = new Scanner(System.in);
  int x = 0;
  System.out.println("How long do you want the first side?");
  int a = r.nextInt();
  System.out.println("How long do you want the second side?");
  int b = r.nextInt();
  System.out.println("How long do you want the third side?");
  int c = r.nextInt();
  Triangle shape = new Triangle(a,b,c);
  System.out.println("What do you want the color?");
  String color = r.next();
  shape.setColor(color);
  shape.setFilled(true);
  
  System.out.println("The color of the triangle is: " + color);
  
  System.out.println("The area of the triangle is: " + shape.getArea());
  
  System.out.println("the perimeter of the triangle is: " + shape.getPerimeter());
  
}
}
