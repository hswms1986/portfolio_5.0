/*
  CS 5000/01
Fall 2015
Henry Williams  
Dr. Haddad
Assignment 9 Time
 */
package time;

/**
 *
 * @author Steven
 */
public class Time {

    private int hour;
    private int minute;
    private int seconds;
    
    public Time() {
        this(System.currentTimeMillis());
    }
    
    public Time(long elapseTime) {
        long allSeconds = elapseTime/1000L;
        this.seconds = (int)(allSeconds % 60L);
        long allMinutes = elapseTime/60L;
        this.minute =(int)(allMinutes/60L);
        int allHours = (int)(allMinutes/60L);
        this.hour = (allHours % 24);
    }
    
    public int getSecond(){
        return this.seconds;
    
    }
    
    public int getMinute(){
        return this.minute;
        
    }
    
    public int getHour(){
        return this.hour;
    
    }
    
    public void setTime(long elapseTime){
        hour = (int)((elapseTime/(1000*60*60))%24);
        minute = (int)((elapseTime/(1000*60))%60);
        seconds =(int)((elapseTime/1000)%60);
    }
    
    public String toString(){
        return this.hour + ":" + this.minute + ":" + this .seconds;
        
    }
    
    }
    
