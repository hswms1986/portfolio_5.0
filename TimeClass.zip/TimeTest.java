/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package time;

/**
 *
 * @author Steven
 */
public class TimeTest {
    public static void main(String []args){
        Time start = new Time();
        System.out.println(start);
        Time end = new Time();
        System.out.println(end);
        end.setTime(555550000);
        System.out.println(end);
    }
}
