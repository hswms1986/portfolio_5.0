/*
  CS 5000/01
Fall 2015
Henry Williams  
Dr. Haddad
Assignment 10 Student
 */
package person;

/**
 *
 * @author Steven
 */
public class Student extends Person {
   
   
    public final String class_stat;
    
    
    public Student(String name, String address, String phone, String email, String grade) {
        super(name, address, phone, email);
        this.class_stat = grade;
    }
    
   
    
    public String toString() {
    return "Name: " + super.getName() + "\n" +
           "He lives at: " + super.getAddress() + "\n" + 
           "Call him at: " + super.getPhone() + "\n" + 
           "Email him at: " + super.getEmail() + "\n" +
           "They are a " + class_stat;
}
    
}
