/*
   CS 5000/01
Fall 2015
Henry Williams  
Dr. Haddad
Assignment 10 Employee
 */
package person;
import java.util.Date;
/**
 *
 * @author Steven
 */
public class Employee extends Person {
    
    long salary;
    Date hired;
    String office;
    
    public Employee(String name, String address, String phone, String email) {
        super(name, address, phone, email);
}
    
public Employee(long salary, String office, Date hired) {
    this.salary = salary;
    this.office = office;
    this.hired = hired;
}

public long getSalary() {
    return salary;
}

public void setSalary(long salary) {
    this.salary = salary;
}

public String office() {
    return office;
}

public void setOffice(String office) {
    this.office = office;
}

public Date hired() {
    return hired;
}

public void setHired(Date hired) {
    this.hired = hired;
}

public String toString() {
    return "Name: " + super.getName() + "\n" +
           "He lives at: " + super.getAddress() + "\n" + 
           "Call him at: " + super.getPhone() + "\n" + 
           "Email him at: " + super.getEmail();
}

}
