/*
  CS 5000/01
Fall 2015
Henry Williams  
Dr. Haddad
Assignment 10 Faculty
 */
package person;

/**
 *
 * @author Steven
 */
public class Faculty extends Employee {
    
    String offhours;
    String rank;
    
public Faculty(String name, String address, String phone, String email) {
        super(name, address, phone, email);
}

public String toString() {
    return "Name: " + super.getName() + "\n" +
           "He lives at: " + super.getAddress() + "\n" + 
           "Call him at: " + super.getPhone() + "\n" + 
           "Email him at: " + super.getEmail();
}
}
