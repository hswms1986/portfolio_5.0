/*
  CS 5000/01
Fall 2015
Henry Williams  
Dr. Haddad
Assignment 10 PersonTest
 */
package person;

/**
 *
 * @author Steven
 */
public class PersonTest extends Person{
    public static void main(String[] args) {
         Person person = new Person("Steven Williams", "00 yeti street", "678-555-1332", "batman3820@yahoo.com");
        Person student = new Student("Henry Williams", "77 Flooded Brook", "404-575-4956", "hw394@abc.com", "senior");
        Person employee = new Employee("Tom Brady", "45 Sky High", "770-567-3210", "tb@xyz.com");
        Person faculty = new Faculty("Arnold Schwarzeneggar", "66 beach pkwy", "404-123-4567", "pumpUup@abc.com");
        Person staff = new Staff("Jack Black", "33 jabroni blvd", "770-201-2112", "black@jack.com");

        System.out.println(person.toString());
        System.out.println("\n" + student.toString());
        System.out.println("\n" + employee.toString());
        System.out.println("\n" + faculty.toString());
        System.out.println("\n" + staff.toString());
        
    }
    
}
