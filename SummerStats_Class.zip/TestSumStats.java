package summerstats;

/*
   CS 5000/01
Fall 2015
Henry Williams  
Dr. Haddad
Assignment 9 TestSumStats
 */

/**
 *
 * @author Steven
 */
public class TestSumStats {
    
    
    public static void main(String[] args){
        SummerStats test = new SummerStats(2, 5);
       
        
        int [] sal = test.maxIndex(test.getSalary());
        
        int year = test.maxYear(test.getSalary());
        
        double money = test.TotalSalary(test.getSalary(), 4);
        
        double sm = test.Sum(test.getSalary());
        
        double wage = test.TopSalary(test.getSalary(), 1);
        
        double [][] gross = test.TotalPerPerson(test.getSalary(), 2, 2);
        
        System.out.println(sal);
        System.out.println(year);
        System.out.println(money);
        System.out.println(sm);
        System.out.println(wage);
        System.out.println(gross);
        
        
        
    }
    
        
    }
    
        
    
    

