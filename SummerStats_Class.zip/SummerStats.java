/*
  CS 5000/01
Fall 2015
Henry Williams  
Dr. Haddad
Assignment 9 SummerStats
 */
package summerstats;

import java.util.*;
import java .lang.Math;
import java.util.Arrays;
import java.util.Random;

public class SummerStats {

    Random answ = new Random();
    private double [][] salary;
    
    SummerStats(int person, int year) {
        salary = new double[person][year];
        for(int i = 0; i < person; i++) {
            for(int j = 0; j < year; j++) {
                salary[i][j] = (Math.random() * 100);
            }
        }
    }
    public double [][] getSalary(){
        
        return salary;
    }
    public int [] maxIndex(double n[][]) {
        int [] biggest = new int[2];
        for(int s = 0; s < n.length; s++){
            double [][] top = new double[1][1];
            for(int t = 0; t < n.length; t++) {
                top[0][0] = n[0][0];
                if(n[s][t] > top[0][0])
                    biggest[0] = s;
                biggest[1] = t;
            }
            
        }
    return biggest;
    }
    public int maxYear(double n[][]) {
        int top = 0;
        for(int x = 0; x < n.length; x++) {
            double [][] max = new double[1][1];
            for(int y = 0; y < n.length; y++) {
                max[0][0] = n[0][0];
                if(n[x][y] > max[0][0])
                   top = y;
        }
    }
        return top;
    }
    public double TotalSalary(double [][] p, int column) {
        int total = 0;
        for(int x = 0; x < p.length; x++){
            total += p[x][column];
            
        }
        return total;
    }
    public double Sum(double[][] p) {
        double sum = 0;
        for(int x = 0; x < p.length; x++){
            for(int y = 0; y < p[x].length; y++){
                
            sum += p[x][y];
            
        }
       
    }
         return sum;
    }
    public double TopSalary(double [][] p, int column) {
        double top = 0;
        for(int x = 0; x < p.length; x++){
            if(top < p[x][column])
                top = p[x][column];
        }
        return top;
    }
    public double[] Average(double [][] p, int year) {
        double [] average = new double[year];
        for(int x = 0; x < p.length; x++){
            double max = 0;
            for(int y = 0; y < p[x].length; y++) {
                max += p[x][y];
            }
            average[x] = max/x;
        }
        return average;
    }
    public double[][] TotalPerPerson(double [][] p, int person,int year) {
        double [][] TotalSalary = new double[person][year];
        double total = 0;
        for(int x = 0; x < p.length; x++){
            for(int y = 0; y < p[x].length; y++) {
                total += p[x][y];
                
            }
            
        }
        total=0;
        return TotalSalary;
    }
    
    
}
